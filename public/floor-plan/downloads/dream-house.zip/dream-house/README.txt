Dream House

Floor plans: scalable SVG drawings.
Exterior and interior: current WebP images.
Images are conceptual studies; use the drawings for plan dimensions.
